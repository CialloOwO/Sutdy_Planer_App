import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/study_task.dart';

class DBHelper {
  // Singleton pattern to ensure only one instance of the database exists
  static final DBHelper instance = DBHelper._init();
  static Database? _database;

  DBHelper._init();

  /// Get the database instance, initialize it if it hasn't been created yet.
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('study_planner.db');
    return _database!;
  }

  /// Initialize the SQLite database at the device's default database path.
  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

 /// Create the database table for storing study tasks.
  Future _createDB(Database db, int version) async {
    // Modified columns to match the new UI requirements
    await db.execute('''
      CREATE TABLE study_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        course TEXT,
        dueDate TEXT,
        status TEXT
      )
    ''');
  }

  // ==========================================
  // CRUD OPERATIONS FOR STUDY TASKS
  // ==========================================

  /// [CREATE] Insert a new task into the database.
  /// Returns the id of the newly inserted row.
  Future<int> insertTask(StudyTask task) async {
    final db = await instance.database;
    return await db.insert('study_tasks', task.toMap());
  }

  /// [READ] Retrieve all tasks from the database.
  /// The results are ordered by the due date in ascending order (earliest first).
  Future<List<StudyTask>> getTasks() async {
    final db = await instance.database;
    final result = await db.query('study_tasks', orderBy: 'dueDate ASC');
    
    // Map the List of JSON objects to a List of StudyTask objects
    return result.map((json) => StudyTask.fromMap(json)).toList();
  }

  /// [UPDATE] Modify an existing task in the database.
  Future<int> updateTask(StudyTask task) async {
    final db = await instance.database;
    return await db.update(
      'study_tasks',
      task.toMap(),
      where: 'id = ?',
      whereArgs: [task.id], // Safely pass the id to prevent SQL injection
    );
  }

  /// [DELETE] Remove a specific task from the database using its id.
  Future<void> deleteTask(int id) async {
    final db = await instance.database;
    try {
      await db.delete(
        'study_tasks',
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      // Log the error for debugging purposes
      print('Error deleting task: \$e');
    }
  }

  /// Close the database connection.
  Future close() async {
    final db = await instance.database;
    db.close();
  }
}